from pathlib import Path
import hashlib,json,os,stat
root=Path('C:/Users/HEQ/Projects/imagejxx').resolve();target=(root/'.cache/uv').resolve()
assert target==root/'.cache/uv' and target.is_relative_to(root)
out=root/'.tmp/manual-workflow-verification/cfg3/uv-cache-retirement002';out.mkdir(exist_ok=False)
def inventory(folder):
 rows={}
 for parent,dirs,files in os.walk(folder,followlinks=False):
  for name in dirs+files:
   path=Path(parent)/name;s=path.lstat()
   assert not path.is_symlink() and not getattr(s,'st_file_attributes',0)&0x400,path
   if stat.S_ISREG(s.st_mode):rows[path.relative_to(folder).as_posix()]={'bytes':s.st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 return rows
for path in (target,*target.parents):
 if path==root.parent:break
 assert not path.is_symlink() and not getattr(path.lstat(),'st_file_attributes',0)&0x400
cache=inventory(target)
distributions=[]
for entry in (target/'archive-v0').iterdir():
 assert entry.is_dir()
 metadata=list(entry.glob('*.dist-info/METADATA'));assert len(metadata)==1,entry
 names={line.split(': ',1)[0]:line.split(': ',1)[1] for line in metadata[0].read_text(encoding='utf-8').splitlines() if line.startswith(('Name: ','Version: '))}
 assert names['Name']=='imagejxx' and names['Version'] in ('0.1.0','0.2.0'),names
 distributions.append({'archive':entry.name,**names})
environments={name:inventory(root/name) for name in ('.venv','.cache/native-verification/runtime')}
for name,rows in environments.items():
 for member in rows:
  if member.endswith(('.pth','pyvenv.cfg','direct_url.json')):
   text=(root/name/member).read_text(encoding='utf-8',errors='replace').lower().replace('\\','/')
   assert '/imagejxx/.cache/uv' not in text,(name,member)
record={'state':'admitted','target':str(target),'bytes':sum(r['bytes'] for r in cache.values()),'files':len(cache),'derived_imagejxx_wheels':distributions,'installed_environments':{name:{'files':len(rows),'bytes':sum(r['bytes'] for r in rows.values())} for name,rows in environments.items()},'basis':'Project cache contains only derived imagejxx0.1/0.2 wheels; installed/runtime roots are independent regular files, managed interpreter home is outside cache. UV in-use checks remain enabled; no force. Original deleted cache bytes will be unavailable, never repinned as current proof.','acceptance':False}
(out/'cache-members.json').write_bytes((json.dumps(cache,indent=2)+'\n').encode())
(out/'environments-before.json').write_bytes((json.dumps(environments,indent=2)+'\n').encode())
(out/'receipt.json').write_bytes((json.dumps(record,indent=2)+'\n').encode())
print('Admitted derived wheel cache:',record['bytes'],'bytes,',len(distributions),'wheel copies; installed environments pinned')
