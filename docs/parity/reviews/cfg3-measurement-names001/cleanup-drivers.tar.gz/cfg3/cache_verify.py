from pathlib import Path
import ast,hashlib,json,os,stat
root=Path('C:/Users/HEQ/Projects/imagejxx');out=root/'.tmp/manual-workflow-verification/cfg3/uv-cache-retirement002'
before=json.loads((out/'environments-before.json').read_bytes())
tree=ast.parse((out.parent/'cache_preflight.py').read_bytes())
function=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='inventory')
namespace={'Path':Path,'os':os,'stat':stat,'hashlib':hashlib}
exec(compile(ast.Module(body=[function],type_ignores=[]),'original-pinned-inventory','exec'),namespace)
after={name:namespace['inventory'](root/name) for name in before}
assert after==before,'Installed environment contents changed during cache cleanup'
assert not (root/'.cache/uv').exists(),'Derived cache entries remain'
receipt=json.loads((out/'receipt.json').read_bytes())
receipt.update(state='retired',removed_logical_bytes=receipt['bytes'],installed_environments_byte_identical=True,cache_present=False)
(out/'verification.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print('Both installed/dependency environments byte-identical;106 obsolete wheel copies retired')
