from pathlib import Path
import hashlib,json,sys
root=Path('C:/Users/HEQ/Projects/imagejxx');sys.path.append(str(root/'.venv/Lib/site-packages'))
import numpy as np
import imagejxx as ij
from imagejxx import _native,_desktop
expected=json.loads((root/'.tmp/manual-workflow-verification/cfg3/windows-final-audit001/receipt.json').read_bytes())['products']
for module in (_native,_desktop):
 path=Path(module.__file__);assert hashlib.sha256(path.read_bytes()).hexdigest()==expected[module.__name__]['sha256']
pixels=np.array([[0,0,0,0,0,0],[0,2,3,4,0,0],[0,5,6,7,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]],np.uint8)
labels,count=ij.label(pixels,connectivity=8,return_num=True);assert count==1
rows=ij.region_properties(labels,intensity=pixels,spacing=(1,1))
assert len(rows)==1 and [rows[0][key] for key in ('min','max','bbox','pixels')]==[2.,7.,(1,1,3,2),6]
record={'state':'passed','acceptance':False,'scope':'Post-cache-clean installed capability/semantic smoke;not another1472-case campaign','products':expected}
out=root/'.tmp/manual-workflow-verification/cfg3/uv-cache-retirement002/smoke.json';assert not out.exists();out.write_bytes((json.dumps(record,indent=2)+'\n').encode())
print('Installed native/Python UI imports and actual particle operation pass after cache retirement')
