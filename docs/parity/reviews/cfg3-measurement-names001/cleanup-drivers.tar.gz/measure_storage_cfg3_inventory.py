"""Complete owned output roots; inaccessible subtrees remain unknown, never zero."""
from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).resolve().parents[2]
old=json.loads((root/'.tmp/p13h-verification/storage-workflow-entry001.json').read_bytes())
values=list(old['roots'])+[str(root/'.cache'),str(root/'.tmp'),str(root/'docs/parity/reviews')]
def normalize(values):
 chosen=[]
 for value in sorted(set(values),key=len):
  if not any(value==parent or value.startswith(parent.rstrip('/\\')+('/' if value.startswith('/') else '\\')) for parent in chosen):chosen.append(value)
 return chosen
walk='''import os,stat,json,sys
rows={};unavailable=[]
for name in json.loads(sys.argv[1]):
 if not os.path.isdir(name):raise RuntimeError('Missing required root:'+name)
 total=0
 def fail(error):unavailable.append({'path':error.filename,'error':str(error)})
 for parent,dirs,files in os.walk(name,followlinks=False,onerror=fail):
  dirs[:]=[n for n in dirs if not os.path.islink(os.path.join(parent,n)) and not getattr(os.lstat(os.path.join(parent,n)),'st_file_attributes',0)&0x400]
  for n in files:
   value=os.lstat(os.path.join(parent,n))
   if stat.S_ISREG(value.st_mode) and not getattr(value,'st_file_attributes',0)&0x400:total+=value.st_size
 rows[name]=total
print(json.dumps({'roots':rows,'unavailable':unavailable}))
'''
started=time.monotonic()
windows=normalize([p for p in values if not p.startswith('/')]);linux=normalize([p for p in values if p.startswith('/')])
a=json.loads(subprocess.check_output([sys.executable,'-I','-B','-c',walk,json.dumps(windows)],text=True))
b=json.loads(subprocess.check_output(['wsl.exe','-d','Ubuntu','--','/usr/bin/python3','-I','-B','-c',walk,json.dumps(linux)],text=True,timeout=60))
rows={**a['roots'],**b['roots']};unknown=a['unavailable']+b['unavailable'];known=sum(rows.values());limit=8*1024**3
within=False if known>limit else None if unknown else True
report={'roots_known_bytes':rows,'known_bytes':known,'unavailable_subtrees':unknown,'limit_bytes':limit,'headroom_upper_bound_bytes':limit-known,'within_budget':within,'budget_verified':within is True,'seconds':time.monotonic()-started,'policy':'All project .cache/.tmp/public retained review roots plus existing dependency/runtime/Linux roots; normalized unique roots; no links; Linux host-local; inaccessible paths unknown','acceptance':False}
path=Path(__file__).parent/(sys.argv[1]+'.json');assert not path.exists();path.write_bytes((json.dumps(report,indent=2)+'\n').encode())
print(json.dumps(report))
if len(sys.argv)<3 or sys.argv[2]!='record-only':assert within is True,'Complete storage budget is not verified'
