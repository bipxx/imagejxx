from pathlib import Path
import gzip,hashlib,json,os,sys
windows=os.name=='nt';host='windows' if windows else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
base=source/'.tmp/manual-workflow-verification/cfg3';out=base/(host+'-measurement-reports');out.mkdir(exist_ok=False)
cpp=base/sys.argv[1]/'cpp/reports/settings-measurements'
python_root=base/sys.argv[2]/'scratch/cfg3-python-ui0'
receipt=json.loads((python_root/'receipt.json').read_bytes());assert receipt['state']=='observed'
mapping={context:{} for context in ('imgui_cpp','imgui_python')};pins=[]
for context in mapping:
 for case in ('measurement-names-edit-persist','measurement-names-reopen'):
  original=cpp/case/'case.json' if context=='imgui_cpp' else Path(receipt['reports'][case])
  raw=original.read_bytes();target=out/(context+'-'+case+'.json.gz')
  with target.open('xb') as stream:
   with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:compressed.write(raw)
  assert gzip.decompress(target.read_bytes())==raw
  mapping[context][case]=str(target)
  pins.append({'original':str(original),'retained':str(target),'raw_sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(base/(host+'-measurement-reports.json')).write_bytes((json.dumps(mapping,indent=2)+'\n').encode())
(out/'receipt.json').write_bytes((json.dumps({'scope':'Byte-exact compressed copies; no new observations','pins':pins,'acceptance':False},indent=2)+'\n').encode())
print('Retained four byte-exact',host,'reports',sum(p.stat().st_size for p in out.iterdir()),'bytes')
