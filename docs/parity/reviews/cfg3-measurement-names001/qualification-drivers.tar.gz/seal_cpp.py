from pathlib import Path
import gzip,hashlib,json,os,sys
host='windows' if os.name=='nt' else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if os.name=='nt' else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
base=source/'.tmp/manual-workflow-verification/cfg3';capture=base/sys.argv[1]/'cpp'
out=base/(host+'-final-measurement-cpp');out.mkdir(exist_ok=False)
mapping={};pins=[]
for case in ('measurement-names-edit-persist','measurement-names-reopen'):
 original=capture/'reports/settings-measurements'/case/'case.json'
 raw=original.read_bytes();target=out/(case+'.json.gz')
 with target.open('xb') as stream:
  with gzip.GzipFile(filename='',fileobj=stream,mode='wb',mtime=0) as compressed:compressed.write(raw)
 assert gzip.decompress(target.read_bytes())==raw
 mapping[case]=str(target);pins.append({'original':str(original),'retained':str(target),'raw_sha256':hashlib.sha256(raw).hexdigest(),'compressed_sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
preferences=capture/'private/settings-measurements/persisted-pair/preferences.json'
raw=preferences.read_bytes();kept=out/'actual-ui-preferences.json';kept.write_bytes(raw)
assert kept.read_bytes()==raw
(out/'receipt.json').write_bytes((json.dumps({'acceptance':False,'scope':'Byte-exact retained actual captures/preferences, no new observations','pins':pins,'preferences':{'original':str(preferences),'retained':str(kept),'sha256':hashlib.sha256(raw).hexdigest()}},indent=2)+'\n').encode())
(base/(host+'-final-measurement-cpp.json')).write_bytes((json.dumps(mapping,indent=2)+'\n').encode())
print('Retained byte-exact CPP reports/preferences for',host)
