from pathlib import Path
import json,os,runpy,sys
root=Path.cwd()
environment=json.loads((root/'.tmp/manual-workflow-verification/cfg3'/sys.argv[2]/'reader-environment.json').read_bytes())
os.environ.update(environment)
sys.argv=[str(root/'.tmp/manual-workflow-verification/ci-recovery001/pytest_run_bound.py'),sys.argv[1],'tests/python/test_settings_measurement_ui.py']
runpy.run_path(sys.argv[0],run_name='__main__')
