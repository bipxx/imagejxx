from pathlib import Path
import hashlib,json,os,shutil,sys
windows=os.name=='nt'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
base=(source/'.tmp/manual-workflow-verification/cfg3').resolve();out=(base/sys.argv[1]).resolve()
assert out.is_relative_to(base) and out!=base
r=json.loads((out/'receipt.json').read_bytes());assert r['state']=='passed' and all(x['state']=='passed' and x['reaped'] for x in r['runs'])
cache=(out/'consumer-cache').resolve();assert cache.parent==out and cache.is_dir() and not cache.is_symlink()
files=[]
for parent,dirs,names in os.walk(cache,followlinks=False):
    for name in dirs+names:
        p=Path(parent)/name;s=p.lstat();assert not p.is_symlink() and not(getattr(s,'st_file_attributes',0)&0x400)
    for name in names:files.append(Path(parent)/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
app=Path(r['consumer']['path']);assert app.is_relative_to(cache) and sha(app)==r['consumer']['sha256']
kept=out/'retained-sdk';kept.mkdir();pins=[]
for p in [app,cache/'CMakeCache.txt']:
    target=kept/p.name;shutil.copy2(p,target);assert sha(target)==sha(p)
    if p==app:assert os.access(target,os.X_OK)
    pins.append({'original':str(p),'retained':str(target),'bytes':p.stat().st_size,'sha256':sha(p)})
record={'state':'retiring','source':str(cache),'removed_bytes':sum(p.stat().st_size for p in files),'verified_retained':pins,'acceptance':False}
path=out/'cache-retirement.json';path.write_text(json.dumps(record,indent=2)+'\n')
for parent,dirs,names in os.walk(cache,topdown=False,followlinks=False):
    for name in names:(Path(parent)/name).unlink()
    for name in dirs:(Path(parent)/name).rmdir()
cache.rmdir();record['state']='retired';path.write_text(json.dumps(record,indent=2)+'\n')
print('Retired SDK generated cache',record['removed_bytes'],'bytes; exact executable/configuration retained')
