from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
windows=os.name=='nt';host='windows' if windows else 'linux'
workspace=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
source=workspace if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
out=source/'.tmp/manual-workflow-verification/cfg3'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
group=sys.argv[2];assert group in ('settings-wand','settings-selection')
app=workspace/('.tmp/p13g-verification/'+host+'/app-installed/bin/imagejxx'+('.exe' if windows else ''))
spec=importlib.util.spec_from_file_location('cfg3_legacy_ci',source/'scripts/ci_observations.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
cases=ci.SETTINGS_WAND_CASES if group=='settings-wand' else ci.SETTINGS_SELECTION_CASES
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={'state':'running','acceptance':False,'group':group,'cases':list(cases),'started':time.time(),'driver_sha256':sha(__file__),'producer_sha256':sha(source/'scripts/ci_observations.py')}
def save():(out/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
save()
try:
 environment=ci.capture(out/'cpp',app,source,os.environ.copy(),selected_cases=[[group,case] for case in cases],case_timeout=60)
 assert sha(__file__)==receipt['driver_sha256'] and sha(source/'scripts/ci_observations.py')==receipt['producer_sha256']
 receipt.update(state='observed',environment=environment)
except BaseException as error:receipt.update(state='failed',error=str(error));raise
finally:receipt['ended']=time.time();save()
