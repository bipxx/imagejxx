"""Host-local identity/cohort join; scientific assertions stay in the readers."""
from pathlib import Path
import gzip,hashlib,json,os,sys,tarfile,xml.etree.ElementTree as ET
windows=os.name=='nt';host='windows' if windows else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
workspace=source if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
base=source/'.tmp/manual-workflow-verification/cfg3';manual=base.parent
cohort_name,build_name,cpp_name,wand_name,selection_name,sdk_name=sys.argv[1:]
out=base/(host+'-final-audit001');out.mkdir(exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
file_sha=lambda p:sha(Path(p).read_bytes())
canonical=lambda value:sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode())
archives={}
def archive(relative,needed):
 path=manual/(relative.replace('/','-')+'.tar.gz')
 retained=json.loads((manual/(relative.replace('/','-')+'-retention.json')).read_bytes())
 assert file_sha(path)==retained['sha256']
 expected={m['path']:m for m in retained['members']};result={}
 with tarfile.open(path,'r:gz') as bundle:
  names=[]
  for member in bundle:
   assert member.isfile() and member.name in expected and member.name not in names
   names.append(member.name);raw=bundle.extractfile(member).read();row=expected[member.name]
   assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
   if member.name in needed:result[member.name]=raw
 assert set(names)==set(expected) and set(result)==set(needed)
 archives[relative]={'path':str(path),'sha256':retained['sha256'],'verified_members':len(names),'bytes':path.stat().st_size}
 return result

receipt={'state':'running','acceptance':False,'scope':'CFG3 focused qualification identity join','host':host}
def save():(out/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
save()
try:
 cohort=base/cohort_name
 run=json.loads((cohort/'receipt.json').read_bytes())
 assert run['state']=='passed' and run['exit_code']==0 and run['cases']==1472
 ids=run['selected_ids'];assert len(ids)==len(set(ids))==1472
 rows=ET.parse(cohort/'report.xml').findall('.//testcase')
 executed=[r.get('classname').replace('.','/')+'.py::'+r.get('name') for r in rows]
 assert executed==ids and all(r.find(k) is None for r in rows for k in ('failure','error','skipped'))
 inputs=json.loads((cohort/'reader-inputs.json').read_bytes())
 assert file_sha(cohort/'reader-inputs.json')==run['reader_manifest_sha256']
 assert len(inputs)==5386 and all(file_sha(source/p)==h for p,h in inputs.items())
 assert all(file_sha(p['path'])==p['sha256'] for p in run['products'].values())
 compiled=json.loads((workspace/'.tmp/manual-workflow-verification/cfg3/build-inputs003.json').read_bytes())
 assert len(compiled)==744 and all(file_sha(source/p)==h for p,h in compiled.items())
 build=base/build_name;built=json.loads((build/'receipt.json').read_bytes())
 assert built['state']=='passed' and all(r['state']=='passed' and r['reaped'] and r['exit_code']==0 for r in built['runs'])
 assert json.loads((build/'source-manifest.json').read_bytes())==compiled
 native=ET.parse(build/'native.xml').findall('.//testcase')
 groups={'native_settings','native_preferences','native_settings_wand_consumer','native_settings_enlargement_consumer','native_settings_measurement_names','desktop_results_measurement_columns'}
 assert {r.get('name') for r in native}==groups and len(native)==6
 assert all(r.find(k) is None for r in native for k in ('failure','error','skipped'))
 log=(build/'native.log').read_text()
 assert '5 groups, 163 checks passed' in log and '4 groups, 11726 checks, 373 actual frames, 38 actual click pairs' in log
 assert 'header=[709,739], data_row_top=739, data_text_top=741, literal_bottom=737' in log
 cpp=archive('cfg3/'+cpp_name,{'cpp/receipt.json'})
 cpp=json.loads(cpp['cpp/receipt.json']);assert cpp['state']=='observed'
 assert file_sha(cpp['application']['path'])==cpp['application']['sha256']
 assert [r['case'] for r in cpp['cases']]==['measurement-names-edit-persist','measurement-names-reopen']
 assert all(r['state']=='observed' and r['exit_code']==0 for r in cpp['cases'])
 cpp_reports=json.loads((base/(host+'-final-measurement-cpp.json')).read_bytes())
 cpp_rows={case:json.loads(gzip.decompress(Path(path).read_bytes())) for case,path in cpp_reports.items()}
 python_root=cohort/'scratch/cfg3-python-ui0'
 python=json.loads((python_root/'receipt.json').read_bytes());assert python['state']=='observed'
 python_rows={case:json.loads(Path(path).read_bytes()) for case,path in python['reports'].items()}
 assert len(python['runs'])==2 and all(r['state']=='observed' and r['launcher_reaped'] for r in python['runs'])
 for r in python['runs']:
  assert all(file_sha(p['path'])==p['sha256'] for p in r['runtime']['products'].values())
  assert all(r['runtime']['products'][name]['sha256']==p['sha256'] for name,p in run['products'].items())
 pids={}
 for context,reports in (('imgui_cpp',cpp_rows),('imgui_python',python_rows)):
  edit=reports['measurement-names-edit-persist'];reopen=reports['measurement-names-reopen']
  assert edit['states']['final_close']['preferences_file']==reopen['states']['loaded']['preferences_file']
  pair=[r['fixture']['runtime']['process_id'] for r in (edit,reopen)];assert len(set(pair))==2
  pids[context]=pair
 for name,group,count in ((wand_name,'settings-wand',4),(selection_name,'settings-selection',4)):
  captured=json.loads((base/name/'cpp/receipt.json').read_bytes())
  assert captured['state']=='observed' and len(captured['cases'])==count
  assert all(r['group']==group and r['state']=='observed' and r['exit_code']==0 for r in captured['cases'])
  assert captured['application']==cpp['application']
 sdk=json.loads((base/sdk_name/'receipt.json').read_bytes())
 assert sdk['state']=='passed' and len(sdk['runs'])==2
 assert all(r['state']=='passed' and r['reaped'] and r['exit_code']==0 for r in sdk['runs'])
 assert file_sha(sdk['consumer']['path'])==sdk['consumer']['sha256'] and file_sha(sdk['core']['path'])==sdk['core']['sha256']
 tools=json.loads((base/('tools-'+host+'001')/'receipt.json').read_bytes());assert tools['state']=='passed' and tools['tests']==19
 receipt.update(state='passed',cases=1472,ordered_nodeids_sha256=canonical(ids),reader_inputs=len(inputs),reader_input_map_sha256=canonical(inputs),compiled_inputs=len(compiled),compiled_input_map_sha256=canonical(compiled),native_groups=sorted(groups),sdk_checks_each=45,transport_tool_tests=19,actual_measurement_process_ids=pids,products=run['products'],application=cpp['application'],archives=archives)
 (out/'ordered-nodeids.json').write_bytes((json.dumps(ids,indent=2)+'\n').encode())
except BaseException as error:receipt.update(state='failed',error=str(error));raise
finally:save()
print(host,'1472 exact outcomes,6 native programs,4 actual UI processes,2 SDK readers joined')
