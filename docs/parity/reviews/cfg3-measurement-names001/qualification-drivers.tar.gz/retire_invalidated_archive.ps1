param([Parameter(Mandatory=$true)][string]$ReceiptName)
$ErrorActionPreference = 'Stop'
$taskWorkspace = (Resolve-Path -LiteralPath 'C:\Users\HEQ\Projects\imagejxx').Path
$taskCache = (Resolve-Path -LiteralPath (Join-Path $taskWorkspace '.cache\native-verification\windows')).Path
$taskLibrary = (Resolve-Path -LiteralPath (Join-Path $taskCache 'Release\imagejxx_desktop.lib')).Path
if ($taskLibrary -ne ($taskCache + '\Release\imagejxx_desktop.lib') -or -not $taskCache.StartsWith($taskWorkspace + '\')) { throw 'Unexpected archive target' }
$taskReceiptRoot = Join-Path $taskWorkspace '.tmp\manual-workflow-verification\cfg3'
if ($ReceiptName -notmatch '^[a-z0-9-]+\.json$') { throw 'Expected bounded receipt basename' }
$taskReceiptPath = Join-Path $taskReceiptRoot $ReceiptName
if (Test-Path -LiteralPath $taskReceiptPath) { throw 'Do not overwrite retirement receipt' }
$taskWalk = Get-Item -LiteralPath $taskLibrary
while ($taskWalk.FullName -ne $taskWorkspace) {
 if ($taskWalk.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Reparse target/ancestor' }
 if ($taskWalk -is [IO.DirectoryInfo]) { $taskWalk = $taskWalk.Parent } else { $taskWalk = $taskWalk.Directory }
 if (-not $taskWalk) { throw 'Cannot establish owned ancestry' }
}
$taskLive = @(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match '(?i)imagejxx' -and $_.Name -match '^(cl|link|lib|MSBuild|cmake|ctest|imagejxx)\.exe$' })
if ($taskLive.Count) { throw 'Active ImageJXX build/application reader' }
$taskHandle = [IO.File]::Open($taskLibrary, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::None)
$taskHandle.Dispose()
$taskInfo = Get-Item -LiteralPath $taskLibrary
$taskReceipt = [ordered]@{ target=$taskLibrary; bytes=$taskInfo.Length; sha256=(Get-FileHash -LiteralPath $taskLibrary -Algorithm SHA256).Hash.ToLower(); reason='Invalidated generated desktop archive; preserve compiler objects and installed products for incremental relink without duplicate archive peak'; live_imagejxx_build_or_application_processes=0; exclusive_read_open_passed=$true; reparse_ancestors=$false; invalidating_inputs=@{}; state='admitted'; acceptance=$false }
foreach ($taskInput in @('CMakeLists.txt','src\desktop\settings_measurement_ui_probe.cpp')) { $taskReceipt.invalidating_inputs[$taskInput]=(Get-FileHash -LiteralPath (Join-Path $taskWorkspace $taskInput) -Algorithm SHA256).Hash.ToLower() }
[IO.File]::WriteAllText($taskReceiptPath, ($taskReceipt | ConvertTo-Json -Depth 5))
Remove-Item -LiteralPath $taskLibrary
if (Test-Path -LiteralPath $taskLibrary) { throw 'Retirement incomplete' }
$taskReceipt.state='retired'
[IO.File]::WriteAllText($taskReceiptPath, ($taskReceipt | ConvertTo-Json -Depth 5))
Write-Output ('Retired invalidated generated archive: ' + $taskReceipt.bytes + ' bytes')
