from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('C:/Users/HEQ/Projects/imagejxx')
base=root/'.tmp/manual-workflow-verification/cfg3';manual=base.parent
out=root/'docs/parity/reviews/cfg3-measurement-names001';out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
canonical=lambda value:hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
platforms={host:json.loads((base/(host+'-final-audit001/receipt.json')).read_bytes()) for host in ('windows','linux')}
for value in platforms.values():assert value['state']=='passed'
for key in ('cases','ordered_nodeids_sha256','reader_input_map_sha256','compiled_input_map_sha256','native_groups'):
 assert platforms['windows'][key]==platforms['linux'][key]
compiled=json.loads((base/'build-inputs003.json').read_bytes())
assert canonical(compiled)==platforms['windows']['compiled_input_map_sha256']
assert all(sha(root/p)==h for p,h in compiled.items())
(out/'compiled-inputs.json').write_bytes((json.dumps(compiled,indent=2)+'\n').encode())
ids=(base/'windows-final-audit001/ordered-nodeids.json').read_bytes()
assert ids==(base/'linux-final-audit001/ordered-nodeids.json').read_bytes()
(out/'affected-nodeids.json').write_bytes(ids)
protected={
 'tests/reference/continuous_bezier_exact_reference.py':'9636659391cc3c4a5fab17f42b7497da8dfb383818a12a78d4967c5552bb382b',
 'tests/reference/ObserveContinuousPathBooleans.java':'b3b64e67e4ded1a660af59d86bb4a8943c4d44d32264e232ea16c53d02d29182',
 'docs/packets/CG0-analytic-reference-contract.md':'3e7da966e20d14756ea417f6d31580753038380157b55d2c311d02fe5122749a',
 'docs/packets/CG0-imagej-observer-contract.md':'eb3eaacda74033a1e71ba52e8aa36cb341d6459144d6a397df2b628044d727bf'}
assert all(sha(root/p)==h for p,h in protected.items())
windows_archives=[]
for name in ('windows-final-cohort001','windows-final-wand001','windows-final-selection001','windows-final-ui001'):
 path=manual/('cfg3-'+name+'-retention.json');retained=json.loads(path.read_bytes());archive=manual/retained['archive']
 assert sha(archive)==retained['sha256']
 windows_archives.append({'name':name,'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':retained['sha256']},'retention_receipt':{'path':str(path),'sha256':sha(path)},'verified_members':len(retained['members']),'raw_retired':True})
retained={'windows':windows_archives,'linux':json.loads((base/'linux-final-retained.json').read_bytes())['archives']}
tools=json.loads((base/'tools-windows001/receipt.json').read_bytes())
assert all(sha(Path(p))==h for p,h in tools['inputs'].items())
observer_paths=['scripts/ci_observations.py','tests/tools/test_ci_observations.py',
 'tests/python/test_settings_measurement_names.py','tests/python/test_settings_measurement_ui.py',
 'tests/python/test_settings_measurement_capture_profile.py','tests/python/settings_measurement_ui_child.py',
 'tests/python/settings_measurement_ui_runner.py','tests/python/test_settings_wand_ui.py',
 'tests/python/settings_wand_ui_runner.py']
observers={p:sha(root/p) for p in observer_paths}
shutil.copyfile(root/'.cache/native-verification/windows/CMakeCache.txt',base/'windows-final-CMakeCache.txt')
members={}
for pattern in ('*.py','*.ps1','*-CMakeCache.txt','build-inputs*.json'):
 for p in base.glob(pattern):members[p.name]=p
for directory in ('reader001-preimage','windows-build001/source-preimages','qualified002-preimages'):
 for p in (base/directory).rglob('*'):
  if p.is_file():members[p.relative_to(base).as_posix()]=p
archive=out/'qualification-drivers.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6) as bundle:
 for name,p in sorted(members.items()):bundle.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as bundle:
 assert set(bundle.getnames())==set(members)
 for name,p in members.items():assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==sha(p)
receipt={
 'schema':'cfg3.scoped-qualification.001','state':'scoped-qualified','acceptance':False,
 'packet_scope_qualified':True,'complete_requirement_coverage':False,'full_ci_qualified':False,
 'baseline_commit':'40130ba5631a537a1bf4a3a55d9e549947c330d3',
 'scope':'Actual measurement-name entry/validation/Apply-Cancel-Defaults-Revert, literal control-name identities, rendered Results/full CSV/fresh persisted hosts, 1024-column paging and multiline literal headers',
 'qualified_settings':['measurements'],
 'contract':{'native_processing_kernel_changed':False,'new_dependencies':0,
  'native_limits':'1024 exact distinct names,1..256 bytes; only all-space/tab/CR/LF refused; no trimming/case folding or new Settings UTF-8 restriction',
  'publication':'Detached validated list changes draft; Apply alone saves; pending unadded text is ignored',
  'results':'64-column pages preserve full ordered1024-name CSV; literal ## and multiline names retain raw keys',
  'source_preservation':'Exact sample words, owners, carriers, revisions, display, history and raw particle results'},
 'platforms':platforms,'retained_final_archives':retained,
 'compiled_inputs':{'path':'compiled-inputs.json','sha256':sha(out/'compiled-inputs.json'),'entries':744},
 'affected_nodeids':{'path':'affected-nodeids.json','sha256':sha(out/'affected-nodeids.json'),'count':1472},
 'observer_sources':observers,
 'qualification_drivers':{'path':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'members':{name:sha(p) for name,p in sorted(members.items())}},
 'new_native_checks_each_platform':{'settings_groups':5,'settings_checks':163,'results_groups':4,'results_checks':11726,'actual_results_frames':373,'actual_click_pairs':38},
 'sdk':'Unchanged installed core/consumer bytes reused; fresh final actual CPP and Python UI preference files read in separate owned runs,45 checks each',
 'failed_and_superseded_attempts':[
  {'attempt':'windows-build001','result':'Compiled;5 native programs passed, wide Results test failed exposing tail field with fixed one-way wheel steps','classification':'Observer helper','preservation':'Original native log/XML/manifest and source preimages retained; adaptive actual scrolling preserves all visibility/CSV assertions'},
  {'attempt':'windows-ui-reader001','result':'2 reopen cases passed;4 edit/join cases refused579800-node report at unchanged500000-node guard','classification':'Observation payload','preservation':'Exact reader and original captures losslessly retained; only unused per-frame data projected out, full checkpoints/input retained'},
  {'attempt':'projection-estimate001','result':'First prospective projection still506475nodes; no new product observation or acceptance','classification':'Development estimate'},
  {'attempt':'windows-build002','result':'Peak admission refused before configure/build; refined from measured existing artifacts and serial links','classification':'Storage admission'},
  {'attempt':'linux-reader-setup-failure001','result':'Missing shared runpy helper before pytest; exact existing helper synchronized','classification':'Harness setup'},
  {'attempt':'linux-multiline-before001','result':'New additive test fails unchanged previous paged product:26px text in17px header; fixed final header30px with nonoverlapping data','classification':'Confirmed UI defect','preservation':'Original product/library hashes and exact old Window/new test identities retained; old generated library bytes are not retained'},
  {'attempt':'qualified002','result':'Both1472-case cohorts passed before additive multiline defect was discovered; retained as previous-source proof only','classification':'Superseded qualification'}],
 'storage_policy':'One compiler cache/runtime per platform; verified lossless capture retention, invalidated generated archives retired before relink; no build/ generation or environment/SDK archive',
 'protected_cg0_sources_unchanged':protected,
 'remaining':{'families':{'total':99,'in_progress':47,'open':52,'complete':0},
  'unqualified':['full hosted CI/platform profiles','macOS','genuine OS input','physical GPU/accessibility','full supported release','strict unavailable G016 historical evidence','remaining ImageJ/Fiji requirements']},
 'next':'CI2 bounded installed-platform entry/profile work; dependency delivery blocks its consumers, not independent editor implementation'}
(out/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
print('Recorded scoped CFG3 proof without build assets or full capture payloads:',out)
