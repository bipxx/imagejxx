from pathlib import Path
import hashlib,json,os,subprocess,sys,time
windows=os.name=='nt';host='windows' if windows else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
base=source/'.tmp/manual-workflow-verification/cfg3';out=base/sys.argv[1];out.mkdir(exist_ok=False)
original=base/('windows-sdk-smoke001' if windows else 'linux-sdk001')
old=json.loads((original/'receipt.json').read_bytes());assert old['state']=='passed'
app=original/'retained-sdk'/('imagejxx_settings_measurements_example.exe' if windows else 'imagejxx_settings_measurements_example')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(app)==old['consumer']['sha256'] and sha(old['core']['path'])==old['core']['sha256']
assert sha(source/'examples/cpp/settings_measurements.cpp')==old['example_sha256']
receipt={'state':'running','acceptance':False,'scope':'Fresh final UI-file reads through unchanged installed SDK consumer/core','original_sdk_receipt_sha256':sha(original/'receipt.json'),'consumer':{'path':str(app),'sha256':sha(app)},'core':old['core'],'runs':[]}
def save():(out/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
save()
try:
 for index,name in enumerate(sys.argv[2:]):
  path=Path(name).resolve(strict=True);before=sha(path)
  row={'argv':[str(app),str(path)],'preferences_sha256':before,'started':time.time(),'state':'running'};receipt['runs'].append(row);save()
  with (out/('read-'+str(index)+'.log')).open('xb') as log:
   child=subprocess.Popen(row['argv'],cwd=source,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait(timeout=30)
  row.update(exit_code=code,reaped=True,ended=time.time());save()
  assert code==0 and sha(path)==before and sha(app)==old['consumer']['sha256']
  assert (out/('read-'+str(index)+'.log')).read_text().strip()=='45 installed measurement-name checks passed'
  row['state']='passed';save()
 assert len(receipt['runs'])==2 and sha(old['core']['path'])==old['core']['sha256']
 receipt['state']='passed'
except BaseException as error:receipt.update(state='failed',error=str(error));raise
finally:save()
print(host,'2 actual final UI preference files,45 SDK checks each')
