from pathlib import Path
import hashlib,importlib.util,json,os,sys,time,xml.etree.ElementTree as ET
windows=os.name=='nt'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
base=source/'.tmp/manual-workflow-verification/cfg3';out=base/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
sys.path.append(str(source/'.venv/Lib/site-packages') if windows else '/home/heq/.cache/imagejxx-build/p08k-001-5zn6rc00/python001/lib/python3.12/site-packages')
os.environ.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',IMAGEJXX_REQUIRE_RENDER_TESTS='1',IMAGEJXX_RENDER_TESTS='1')
import pytest
from imagejxx import _native,_desktop
spec=importlib.util.spec_from_file_location('cfg3_readers',source/'scripts/ci_observations.py');ci=importlib.util.module_from_spec(spec);spec.loader.exec_module(ci)
os.environ.update(ci.reader_environment(base/sys.argv[2]/'cpp'))
os.environ['IMAGEJXX_SETTINGS_WAND_CPP_REPORTS']=ci.reader_environment(base/sys.argv[3])['IMAGEJXX_SETTINGS_WAND_CPP_REPORTS']
os.environ['IMAGEJXX_SETTINGS_SELECTION_CPP_REPORTS']=ci.reader_environment(base/sys.argv[4])['IMAGEJXX_SETTINGS_SELECTION_CPP_REPORTS']
os.environ['IMAGEJXX_SETTINGS_MEASUREMENT_CPP_REPORTS']=(base/(('windows' if windows else 'linux')+'-final-measurement-cpp.json')).read_text()
modules=['test_settings_measurement_names','test_settings_measurement_ui','test_settings_measurement_capture_profile','test_settings_wand_capture_profile','test_settings_enlargement_consumer','test_settings_selection_ui','test_settings_wand_ui',
         'test_settings','test_native_preferences','test_selection_enlargement',
         'test_selection_enlargement_command','test_selection_enlargement_workflow',
         'test_region_enlargement_command','test_conversion_options','test_startup_settings_export']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={p.relative_to(source).as_posix():sha(p) for folder in ('tests/python','tests/fixtures')
        for p in (source/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts}
(out/'reader-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
products={m.__name__:{'path':m.__file__,'sha256':sha(m.__file__)} for m in (_native,_desktop)}
receipt={'state':'running','acceptance':False,'modules':modules,'products':products,'selected_ids':[],
         'reader_manifest_sha256':sha(out/'reader-inputs.json'),'helper_sha256':sha(__file__),'started':time.time()}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
class Collection:
    def pytest_collection_modifyitems(self,items):
        ids=[i.nodeid for i in items];assert ids and len(ids)==len(set(ids));receipt['selected_ids']=ids;save()
save()
try:
    os.chdir(source)
    code=pytest.main(['tests/python/'+m+'.py' for m in modules]+['-q','-p','no:cacheprovider','--tb=short','--basetemp='+str(out/'scratch'),'--junitxml='+str(out/'report.xml')],plugins=[Collection()])
    receipt['exit_code']=int(code);rows=ET.parse(out/'report.xml').findall('.//testcase')
    ids=[r.get('classname').replace('.','/')+'.py::'+r.get('name') for r in rows]
    assert code==0 and ids==receipt['selected_ids'] and all(r.find(k) is None for r in rows for k in ('failure','error','skipped'))
    assert all(sha(source/p)==h for p,h in inputs.items()) and all(sha(p['path'])==p['sha256'] for p in products.values())
    assert sha(__file__)==receipt['helper_sha256'];receipt.update(state='passed',cases=len(rows))
except BaseException as e:receipt.update(state='failed',error=str(e));raise
finally:receipt['ended']=time.time();save()
