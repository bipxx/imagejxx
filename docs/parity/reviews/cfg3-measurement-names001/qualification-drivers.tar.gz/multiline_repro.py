from pathlib import Path
import hashlib,json,shutil,subprocess,time
workspace=Path('/mnt/c/Users/HEQ/Projects/imagejxx')
source=Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
cache=source.parent/'cache-native001'
out=source/'.tmp/manual-workflow-verification/cfg3/linux-multiline-before001';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
window=source/'src/desktop/window.cpp';library=cache/'libimagejxx_desktop.a'
assert sha(window)=='1160226a3962cc05f5ca272a4bd4fc9b5c843fd8ac144059e6fc0d4a9e01a099'
library_before=sha(library)
name='tests/native/test_results_measurement_columns.cpp'
shutil.copyfile(workspace/name,source/name)
receipt={'state':'running','acceptance':False,'scope':'Safe old paged Results multiline-header reproducer','window_sha256':sha(window),'library_sha256':library_before,'new_test_sha256':sha(source/name),'runs':[]}
def save():(out/'receipt.json').write_bytes((json.dumps(receipt,indent=2)+'\n').encode())
def run(name,args):
 row={'name':name,'argv':list(map(str,args)),'started':time.time(),'state':'running'};receipt['runs'].append(row);save()
 with (out/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(row['argv'],cwd=source,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait(timeout=120)
 row.update(state='terminal',exit_code=code,reaped=True,ended=time.time());save();return code
save()
try:
 assert run('build',['/usr/bin/cmake','--build',cache,'--target','imagejxx_results_measurement_columns_tests','--parallel','2'])==0
 assert sha(library)==library_before and sha(window)==receipt['window_sha256']
 code=run('reproduce',[cache/'imagejxx_results_measurement_columns_tests',out/'fixture'])
 log=(out/'reproduce.log').read_text()
 assert code==1 and 'Literal multiline Results header did not reserve its full raw text height and padding' in log
 assert sha(library)==library_before
 receipt.update(state='reproduced',observed_exit_code=code)
except BaseException as error:receipt.update(state='failed',error=str(error));raise
finally:save()
print(log)
