from pathlib import Path
import hashlib, json, os, re, sys, tarfile, xml.etree.ElementTree as ET

windows=os.name=='nt';host='windows' if windows else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
manual=source/'.tmp/manual-workflow-verification';base=manual/'ci-recovery001'
sys.path.extend([str(source/'.venv/Lib/site-packages') if windows else '/home/heq/.cache/imagejxx-build/p08k-001-5zn6rc00/python001/lib/python3.12/site-packages',str(source/'tests/python')])
import test_shadow_demo_ui as comparator
from imagejxx import _native, _desktop
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
    p=Path(p);return {'locator':str(p),'bytes':p.stat().st_size,'sha256':digest(p)}
def junit(raw,ids=None):
    rows=ET.fromstring(raw).findall('.//testcase')
    assert rows and all(c.find(k) is None for c in rows for k in ('error','failure','skipped'))
    actual=[c.get('classname').replace('.','/')+'.py::'+c.get('name') for c in rows]
    if ids is not None:assert actual==ids and len(ids)==len(set(ids))
    return rows
def members(record):
    r=json.loads(Path(record).read_bytes());archive=manual/r['archive']
    assert digest(archive)==r['sha256'];data={}
    with tarfile.open(archive) as bundle:
        expected={m['path']:m for m in r['members']};assert set(bundle.getnames())==set(expected)
        for m in bundle.getmembers():
            assert m.isfile();raw=bundle.extractfile(m).read();expected_row=expected[m.name]
            assert len(raw)==expected_row['bytes'] and hashlib.sha256(raw).hexdigest()==expected_row['sha256']
            data[m.name]=raw
    return data,{'archive':pin(archive),'retention':pin(record),'members_verified':len(data)}

api,api_pin=members(manual/('ci-recovery001-api-'+host+'002-retention.json'))
ar=json.loads(api['receipt.json']);assert ar['state']=='passed' and ar['cases']==317
junit(api['report.xml'],ar['selected_ids'])
inputs=json.loads(api['test-inputs.json'])
assert hashlib.sha256(api['test-inputs.json']).hexdigest()==ar['test_input_manifest_sha256']
assert all(digest(source/p)==h for p,h in inputs.items())
assert digest(Path(__file__).with_name('pytest_run_bound.py'))==ar['helper_sha256']
for p in ar['products'].values():assert digest(p['path'])==p['sha256']
build=base/('windows-build002' if windows else 'linux-build001')
br=json.loads((build/'receipt.json').read_bytes());assert br['state']=='passed'
compiled=json.loads((build/'source-manifest.json').read_bytes())
assert all(digest(source/p)==h for p,h in compiled.items())
native=ET.parse(build/'native.xml').findall('.//testcase')
expected={'native_auto_contrast','native_auto_contrast_jobs','native_auto_contrast_display_reset','native_auto_contrast_sdk_probe'}
assert {r.get('name') for r in native}==expected and len(native)==4
assert all(r.find(k) is None for r in native for k in ('failure','error','skipped'))
log=(build/'native.log').read_text()
for token in ('1355 checks; 64 named cases','428 checks; 54 named cases','271 checks; 19 named cases','13 cases, 485 checks'):assert token in log
shadow=base/('shadow-'+host+'001');sr=json.loads((shadow/'receipt.json').read_bytes())
assert sr['state']=='passed' and len(sr['archives'])==24
assert all(r['state']=='passed' and r.get('reaped') and r['exit_code']==0 for r in sr['runs'])
cases=set(comparator.CASES);seen=set();evidence=[]
for cell in sr['archives']:
    key=(cell['case'],cell['context']);assert key not in seen;seen.add(key)
    data,kept=members(cell['record'])
    test=json.loads(data['pytest/receipt.json']);assert test['state']=='passed' and test['cases']==1
    junit(data['pytest/report.xml'],test['selected_ids'])
    assert test['products']==ar['products']
    reports=[json.loads(raw) for name,raw in data.items() if name.endswith('/case.json')]
    assert len(reports)==1;report=reports[0]
    assert report['context']==cell['context'];comparator.check(report,cell['case'])
    evidence.append({'case':cell['case'],'context':cell['context'],**kept})
assert seen=={(c,x) for c in cases for x in ('imgui_cpp','imgui_python')}
assert all(digest(source/p)==h for p,h in inputs.items())
result={'schema':'ci1.host-audit.001','state':'passed','acceptance':False,'host':host,
        'compiled_inputs':len(compiled),'compiled_manifest':pin(build/'source-manifest.json'),
        'native_programs':sorted(expected),'native_receipt':pin(build/'receipt.json'),'native_xml':pin(build/'native.xml'),
        'api_cases':317,'api_ids':ar['selected_ids'],'api':api_pin,'test_input_manifest_sha256':ar['test_input_manifest_sha256'],
        'products':ar['products'],'shadow_cells':24,'shadow':evidence,
        'saved_result_comparator':{'path':'tests/python/test_shadow_demo_ui.py','sha256':inputs['tests/python/test_shadow_demo_ui.py'],
          'authority':'Current hash-bound saved-result re-audit; original captures/readers keep original protocol; no new GUI capture implied'},
        'limits':'Scoped Windows/Linux Auto and headless/shared ImGui; not full hosted CI, OS/GPU/macOS or release acceptance'}
(base/('audit-'+host+'001.json')).write_text(json.dumps(result,indent=2)+'\n')
print(host,'audit passed:4native,317API,24retainedshadowcells; current reader hashes and every archive member verified')
