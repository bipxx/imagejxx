from pathlib import Path
import hashlib, importlib.util, json, os, subprocess, sys, time

windows=os.name=='nt';host='windows' if windows else 'linux'
workspace=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
source=workspace if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
manual=source/'.tmp/manual-workflow-verification'
out=manual/'ci-recovery001'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
runtime=workspace/'.cache/native-verification/runtime/Scripts/python.exe' if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/p13g-probe-env003/bin/python')
app=workspace/('.tmp/p13g-verification/'+host+'/app-installed/bin/imagejxx'+('.exe' if windows else ''))
helper=workspace/'.tmp/manual-workflow-verification/ci-recovery001/pytest_run.py'
retainer=workspace/('.tmp/manual-workflow-verification/'+('retain.py' if windows else 'retain_linux.py'))
storage=json.loads(Path(sys.argv[2]).read_bytes())
cases=['source'] if '--source-only' in sys.argv else ['source','byte','short','float','rgb','escape','stop','budget','overflow','guard-stack','guard-type','guard-policy']
def size():
    total=0
    for parent,dirs,files in os.walk(manual,followlinks=False):
        dirs[:]=[n for n in dirs if not (Path(parent)/n).is_symlink()]
        for n in files:
            p=Path(parent)/n
            if not p.is_symlink():total+=p.stat().st_size
    return total
initial=size();receipt={'state':'running','acceptance':False,'host':host,'cases':cases,'runs':[],'archives':[],'baseline_storage':storage['bytes']}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save()
spec=importlib.util.spec_from_file_location('owned_ui_tree',source/'tests/python/settings_wand_ui_runner.py')
tree=importlib.util.module_from_spec(spec);spec.loader.exec_module(tree)
def run(name,args,log,environment=None,runtime_path=None):
    row={'name':name,'argv':list(map(str,args)),'state':'running','started':time.time()};receipt['runs'].append(row);save()
    try:
        with log.open('xb') as output:
            child=subprocess.Popen(row['argv'],cwd=source,env=environment,stdout=output,stderr=subprocess.STDOUT,start_new_session=not windows)
            row['pid']=child.pid;save()
            try:code=child.wait(timeout=90)
            except subprocess.TimeoutExpired:
                row['cleanup']=tree.terminate_process_tree(child,runtime_path or log.with_suffix('.runtime.json'));raise
        row.update(exit_code=code,reaped=True)
        if code:raise RuntimeError(name+' failed; see '+str(log))
        row['state']='passed'
    except BaseException as error:
        row.update(state='failed',error=str(error));raise
    finally:row['ended']=time.time();save()
try:
    for case in cases:
        for context in ('imgui_cpp','imgui_python'):
            # No concurrent build or opposite-host capture; include a complete
            # maximum report plus conservative metadata/compression reserve.
            estimate=storage['bytes']+size()-initial+49*1024**2
            assert estimate<storage['limit_bytes'],('Peak capture not admitted',case,context,estimate)
            name=case+'-'+context;cell=out/name;cell.mkdir()
            environment=os.environ.copy()
            if context=='imgui_cpp':
                parent=cell/'cpp';parent.mkdir()
                run(name+'-capture',[app,'--shadow-demo-ui-case',case,parent/case],cell/'capture.log')
                report=parent/case/'case.json';assert 0<report.stat().st_size<=48*1024**2
                environment['IMAGEJXX_SHADOW_DEMO_CPP_BASE']=str(parent)
            node='tests/python/test_shadow_demo_ui.py::test_shadow_demo_canvas_playback_and_restoration['+context+'-'+case+']'
            run(name+'-reader',[runtime,'-I','-X','utf8','-B',helper,cell/'pytest',node],cell/'pytest.log',environment,cell/'pytest/receipt.json')
            r=json.loads((cell/'pytest/receipt.json').read_bytes());assert r['state']=='passed' and r['cases']==1
            relative=cell.relative_to(manual).as_posix()
            run(name+'-retain',[sys.executable,'-I','-B',retainer,relative],out/(name+'-retention.log'))
            record=manual/(relative.replace('/','-')+'-retention.json')
            keep=json.loads(record.read_bytes());archive=manual/keep['archive']
            assert hashlib.sha256(archive.read_bytes()).hexdigest()==keep['sha256'] and not cell.exists()
            receipt['archives'].append({'case':case,'context':context,'record':str(record),'archive':str(archive),'sha256':keep['sha256'],'removed_bytes':keep['removed_bytes'],'retained_bytes':keep['retained_bytes']});save()
    receipt['state']='passed'
except BaseException as error:
    receipt.update(state='failed',error=str(error));raise
finally:save()
