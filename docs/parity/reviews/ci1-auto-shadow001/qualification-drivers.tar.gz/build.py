from pathlib import Path
import hashlib, json, os, subprocess, sys, time

windows = os.name == 'nt'
workspace = Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
linux_base = Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay')
source = workspace if windows else linux_base/'source001'
cache = workspace/'.cache/native-verification/windows' if windows else linux_base/'cache-native001'
root = source/'.tmp/manual-workflow-verification/ci-recovery001'
out = root/sys.argv[1]
out.mkdir(parents=True, exist_ok=False)
inputs = json.loads((workspace/'.tmp/manual-workflow-verification/ci-recovery001/build-inputs.json').read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert all(digest(source/p) == h for p,h in inputs.items())
(out/'source-manifest.json').write_text(json.dumps(inputs, indent=2)+'\n')
cmake = Path('C:/Program Files/Microsoft Visual Studio/2022/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe') if windows else Path('/usr/bin/cmake')
ctest = cmake.with_name('ctest.exe' if windows else 'ctest')
receipt = {'state':'running', 'acceptance':False, 'scope':'CI1 bounded installed build/native regression', 'runs':[]}

def save():
    (out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')

def run(name, args):
    row = {'name':name, 'argv':list(map(str,args)), 'state':'running', 'started':time.time()}
    receipt['runs'].append(row); save()
    try:
        with (out/(name+'.log')).open('xb') as log:
            child = subprocess.Popen(row['argv'], cwd=source, stdout=log, stderr=subprocess.STDOUT)
            row['pid']=child.pid; save(); code=child.wait()
        row.update(exit_code=code, reaped=True)
        if code: raise RuntimeError(name+' failed; see retained log')
        row['state']='passed'
    except BaseException as error:
        row.update(state='failed', error=str(error))
        raise
    finally:
        row['ended']=time.time(); save()

save()
try:
    run('configure',[cmake,'-S',source,'-B',cache])
    targets=['imagejxx_auto_contrast_tests','imagejxx_auto_contrast_jobs_tests',
             'imagejxx_auto_contrast_display_reset_tests','imagejxx_auto_contrast_sdk_probe',
             '_native','_scientific_io','_desktop','imagejxx_app']
    run('build',[cmake,'--build',cache,'--config','Release','--parallel','2','--target',*targets])
    pattern='^native_auto_contrast(_jobs|_display_reset|_sdk_probe)?$'
    collected=json.loads(subprocess.check_output([str(ctest),'--test-dir',str(cache),'-C','Release','-R',pattern,'--show-only=json-v1']))
    assert {t['name'] for t in collected['tests']} == {'native_auto_contrast','native_auto_contrast_jobs','native_auto_contrast_display_reset','native_auto_contrast_sdk_probe'}
    run('native',[ctest,'--test-dir',cache,'-C','Release','-R',pattern,'--no-tests=error','-V','--output-on-failure','--output-junit',out/'native.xml'])
    assert all(digest(source/p)==h for p,h in inputs.items())
    install=json.loads((workspace/('.tmp/p13g-verification/'+('windows' if windows else 'linux')+'/install.json')).read_bytes())
    for name, component in [('processing','processing-python'),('scientific','scientific-python'),('desktop','Unspecified')]:
        run('install-'+name,[cmake,'--install',cache,'--config','Release','--prefix',install['pure'],'--component',component])
    run('install-app',[cmake,'--install',cache,'--config','Release','--prefix',workspace/('.tmp/p13g-verification/'+('windows' if windows else 'linux')+'/app-installed'),'--component','desktop'])
    assert all(digest(source/p)==h for p,h in inputs.items())
    receipt['state']='passed'
except BaseException as e:
    receipt.update(state='failed',error=str(e)); raise
finally:
    save()
