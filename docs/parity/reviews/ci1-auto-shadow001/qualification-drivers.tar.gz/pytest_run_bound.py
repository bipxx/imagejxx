from pathlib import Path
import hashlib, json, os, sys, time, xml.etree.ElementTree as ET

windows=os.name=='nt'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
dependencies=source/'.venv/Lib/site-packages' if windows else Path('/home/heq/.cache/imagejxx-build/p08k-001-5zn6rc00/python001/lib/python3.12/site-packages')
sys.path.append(str(dependencies));os.environ.update(PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',PYTHONDONTWRITEBYTECODE='1',IMAGEJXX_REQUIRE_RENDER_TESTS='1')
import pytest
from imagejxx import _native, _desktop
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
digest=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={p.relative_to(source).as_posix():digest(p)
        for folder in ('tests/python','tests/fixtures') for p in (source/folder).rglob('*')
        if p.is_file() and '__pycache__' not in p.parts}
(out/'test-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
helper_sha256=digest(Path(__file__))
products={m.__name__:{'path':m.__file__,'sha256':digest(m.__file__)} for m in (_native,_desktop)}
receipt={'state':'running','acceptance':False,'process_id':os.getpid(),'parent_process_id':os.getppid(),'products':products,'selected_ids':[],'started':time.time()}
receipt.update(test_input_manifest_sha256=digest(out/'test-inputs.json'),helper_sha256=helper_sha256)
path=out/'receipt.json'
def save():path.write_text(json.dumps(receipt,indent=2)+'\n')
save()
class Collected:
    def pytest_collection_modifyitems(self,items):
        ids=[i.nodeid for i in items];assert ids and len(ids)==len(set(ids))
        receipt['selected_ids']=ids;save()
try:
    os.chdir(source)
    args=[*sys.argv[2:],'-q','-p','no:cacheprovider','--tb=short','--basetemp='+str(out/'scratch'),'--junitxml='+str(out/'report.xml')]
    code=pytest.main(args,plugins=[Collected()]);receipt['exit_code']=int(code)
    rows=ET.parse(out/'report.xml').findall('.//testcase')
    observed={c.get('classname').replace('.','/')+'.py::'+c.get('name') for c in rows}
    assert code==0 and observed==set(receipt['selected_ids']) and len(rows)==len(receipt['selected_ids'])
    assert all(c.find(k) is None for c in rows for k in ('error','failure','skipped'))
    assert all(digest(p['path'])==p['sha256'] for p in products.values())
    assert all(digest(source/p)==h for p,h in inputs.items())
    assert digest(Path(__file__))==helper_sha256
    receipt.update(state='passed',cases=len(rows))
except BaseException as error:
    receipt.update(state='failed',error=str(error));raise
finally:
    receipt['ended']=time.time();save()
