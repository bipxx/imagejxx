from pathlib import Path
import contextlib,hashlib,importlib.util,json,os,sys,unittest
windows=os.name=='nt';host='windows' if windows else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
out=source/'.tmp/manual-workflow-verification/cfg2'/('tools-'+host+'001');out.mkdir(exist_ok=False)
paths=[source/'tests/tools/test_ci_observations.py',source/'scripts/ci_observations.py']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={p.as_posix():sha(p) for p in paths}
spec=importlib.util.spec_from_file_location('cfg2_transport_tests',paths[0]);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
def ids(suite):
    return [name for item in suite for name in (ids(item) if isinstance(item,unittest.TestSuite) else [item.id()])]
selected=ids(suite);assert len(selected)==len(set(selected))==19
with (out/'tests.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
assert result.wasSuccessful() and result.testsRun==19 and not result.skipped
assert all(sha(Path(p))==h for p,h in before.items())
(out/'receipt.json').write_text(json.dumps({'state':'passed','acceptance':False,'scope':'Synthetic transport guards; not actual UI acceptance',
    'inputs':before,'ids':selected,'tests':19,'interpreter':sys.executable},indent=2)+'\n')
print(host,'19transport tests passed with before/after source pins')
