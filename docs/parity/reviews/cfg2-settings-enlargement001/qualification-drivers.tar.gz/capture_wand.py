from pathlib import Path
import importlib.util,os,sys
windows=os.name=='nt';host='windows' if windows else 'linux'
workspace=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
source=workspace if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
out=source/'.tmp/manual-workflow-verification/cfg2'/sys.argv[1]
app=workspace/('.tmp/p13g-verification/'+host+'/app-installed/bin/imagejxx'+('.exe' if windows else ''))
spec=importlib.util.spec_from_file_location('cfg2_legacy_ci',source/'scripts/ci_observations.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.capture(out,app,source,os.environ.copy(),selected_cases=[['settings-wand',case] for case in module.SETTINGS_WAND_CASES],case_timeout=60)
