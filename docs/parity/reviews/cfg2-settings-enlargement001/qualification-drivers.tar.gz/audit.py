from pathlib import Path
import difflib,hashlib,json,os,re,sys,tarfile,xml.etree.ElementTree as ET
windows=os.name=='nt';host='windows' if windows else 'linux'
source=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
manual=source/'.tmp/manual-workflow-verification';base=manual/'cfg2'
sys.path.extend([str(source/'.venv/Lib/site-packages') if windows else '/home/heq/.cache/imagejxx-build/p08k-001-5zn6rc00/python001/lib/python3.12/site-packages',str(source/'tests/python')])
import test_settings_selection_ui as reader
from imagejxx import _native,_desktop
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):
    p=Path(p);return {'locator':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def archive(name):
    metadata=manual/(name.replace('/','-')+'-retention.json');r=json.loads(metadata.read_bytes());p=manual/r['archive']
    assert sha(p)==r['sha256'];data={}
    with tarfile.open(p) as bundle:
        expected={m['path']:m for m in r['members']};assert set(bundle.getnames())==set(expected)
        for member in bundle.getmembers():
            assert member.isfile();raw=bundle.extractfile(member).read();m=expected[member.name]
            assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256'];data[member.name]=raw
    return data,{'archive':pin(p),'retention':pin(metadata),'members_verified':len(data),'raw_retired_bytes':r['removed_bytes']}
full_name='full-windows002' if windows else 'full-linux001'
full,full_pin=archive('cfg2/'+full_name);f=json.loads(full['receipt.json']);assert f['state']=='passed' and f['cases']==1417
rows=ET.fromstring(full['report.xml']).findall('.//testcase')
assert len(rows)==1417 and all(r.find(k) is None for r in rows for k in ('failure','error','skipped'))
ids=[r.get('classname').replace('.','/')+'.py::'+r.get('name') for r in rows]
assert ids==f['selected_ids'] and len(ids)==len(set(ids))
inputs=json.loads(full['reader-inputs.json']);assert hashlib.sha256(full['reader-inputs.json']).hexdigest()==f['reader_manifest_sha256']
changed='tests/python/test_settings_selection_ui.py'
workspace=source if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
preimage=workspace/'.tmp/manual-workflow-verification/cfg2/ui-reader-preimage.py'
assert sha(preimage)==inputs[changed]
current=(source/changed).read_bytes();old=preimage.read_bytes()
additions=[b"    assert len(state['settings']) == 61\n",b"                assert state['settings'] == baseline['settings']\n",
           b"        assert not states['final_cancel']['observations']['preferences_panel']['open']\n",
           b"        assert states['final_cancel']['owners'] == states['shown']['owners']\n"]
reconstructed=current
for addition in additions:
    assert reconstructed.count(addition)==1;reconstructed=reconstructed.replace(addition,b'',1)
assert reconstructed==old
reader_successor={'path':changed,'original_sha256':inputs[changed],'current_sha256':sha(source/changed),'original_source':pin(preimage),
    'authority':'Four additive invariant assertions only; current comparator rechecks every original complete UI snapshot below, no new GUI observation implied'}
assert all(sha(source/p)==h for p,h in inputs.items() if p!=changed) and sha(Path(__file__).with_name('full_tests.py'))==f['helper_sha256']
assert all(sha(p['path'])==p['sha256'] for p in f['products'].values())
assert any('test_settings_in_hidden_opengl_and_recreated_context' in p for p in ids)
assert any('test_conversion_forms_render_in_hidden_opengl' in p for p in ids)
build=base/('windows-build001' if windows else 'linux-build001');b=json.loads((build/'receipt.json').read_bytes());assert b['state']=='passed'
compiled=json.loads((build/'source-manifest.json').read_bytes());assert len(compiled)==738 and all(sha(source/p)==h for p,h in compiled.items())
native=ET.parse(build/'native.xml').findall('.//testcase')
groups={'native_settings_enlargement_consumer','native_settings','native_settings_wand_consumer','native_preferences','native_selection_enlargement','native_selection_enlargement_command','native_region_enlargement_command','desktop_enlargement_dialog'}
assert len(native)==8 and {r.get('name') for r in native}==groups
assert all(r.find(k) is None for r in native for k in ('failure','error','skipped'))
native_log=(build/'native.log').read_text();assert all(name in native_log for name in ('CFG2-N01-defaults-types','CFG2-N02-atomic-pair','CFG2-N03-literal-unit-consumption','CFG2-N04-transient-history-and-overrides','CFG2-P01-strict-file-roundtrip'))
cpp_name='cpp-windows002' if windows else 'cpp-linux001';cpp,cpp_pin=archive('cfg2/'+cpp_name)
c=json.loads(cpp['cpp/receipt.json']);assert c['state']=='observed' and len(c['cases'])==4
assert sha(c['application']['path'])==c['application']['sha256']
observations={}
for item in c['cases']:
    assert item['state']=='observed' and item['exit_code']==0
    case=item['case'];actual=Path(item['actual']).relative_to(base/cpp_name).as_posix()
    transport=Path(item['transport']).relative_to(base/cpp_name).as_posix()
    assert cpp[actual+'/case.json']==cpp[transport+'/case.json']
    identity=json.loads(cpp[actual+'/runtime.json']);row=reader.decode(cpp[transport+'/case.json'])
    assert row['fixture']['runtime']==identity and identity['parent_process_id']==item['capture_process_id']
    assert hashlib.sha256(cpp[actual+'/runtime.json']).hexdigest()==item['runtime']['sha256']
    assert row['context']=='imgui_cpp' and row['case_id']==case;reader.check_case(row);observations[('imgui_cpp',case)]=row
producers=[(name,json.loads(raw)) for name,raw in full.items() if name.endswith('/receipt.json') and 'cfg2-python-ui' in name]
assert len(producers)==1;parent,pr=producers[0];assert pr['state']=='observed' and len(pr['runs'])==4
prefix=parent.rsplit('/',1)[0]
for run in pr['runs']:
    assert run['state']=='observed' and run['exit_code']==0 and run['launcher_reaped']
    case=run['case'];relative=Path(pr['reports'][case]).relative_to(base/full_name).as_posix();row=reader.decode(full[relative])
    identity=run['runtime'];assert row['fixture']['runtime']=={'process_id':identity['process_id'],'parent_process_id':identity['parent_process_id']}
    assert identity['process_id']==run['launcher_process_id'] or identity['parent_process_id']==run['launcher_process_id']
    assert all(identity['products'][name]['sha256']==p['sha256'] for name,p in f['products'].items())
    assert all(sha(p['path'])==p['sha256'] for p in identity['products'].values())
    assert hashlib.sha256(full[relative]).hexdigest()==run['report_sha256']
    assert row['context']=='imgui_python' and row['case_id']==case;reader.check_case(row);observations[('imgui_python',case)]=row
assert set(observations)=={(context,case) for context in reader.CONTEXTS for case in reader.CASES}
for context in reader.CONTEXTS:
    before=observations[(context,'enlargement-persist')];after=observations[(context,'enlargement-reopen')]
    assert before['states']['closed']['preferences_file']==after['states']['loaded']['preferences_file']
    assert before['fixture']['runtime']['process_id']!=after['fixture']['runtime']['process_id']
legacy,legacy_pin=archive('cfg2/legacy-cpp-'+host+'001');lr=json.loads(legacy['receipt.json']);assert lr['state']=='observed' and len(lr['cases'])==4
assert sha(lr['application']['path'])==c['application']['sha256']
sdk=base/('sdk-'+host+'001');s=json.loads((sdk/'receipt.json').read_bytes());assert s['state']=='passed'
retired=json.loads((sdk/'cache-retirement.json').read_bytes());assert retired['state']=='retired'
for p in retired['verified_retained']:assert sha(p['retained'])==p['sha256']
assert sha(source/'examples/cpp/settings_selection.cpp')==s['example_sha256'] and sha(s['core']['path'])==s['core']['sha256']
pref=base/('ui-preferences-windows002' if windows else 'ui-preferences-linux001')
if windows:
    sr=json.loads((pref/'receipt.json').read_bytes());assert sr['state']=='passed' and sr['consumer_sha256']==s['consumer']['sha256']
    files=sr['files']
else:
    files=[{'context':name,'retained':str(pref/(name+'.json')),'sha256':p['sha256']} for name,p in json.loads((pref/'origins.json').read_bytes()).items()]
assert {p['context'] for p in files}=={'cpp','python'}
for p in files:
    context='imgui_'+p['context'];raw=Path(p['retained']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==p['sha256']==observations[(context,'enlargement-persist')]['states']['closed']['preferences_file']['sha256']
    text=(pref/(p['context']+'.log')).read_text() if windows else (sdk/('read-'+str(0 if p['context']=='cpp' else 1)+'.log')).read_text()
    assert '2348 installed enlargement preferences checks passed' in text
assert [p['sha256'] for p in s['preferences']]==[p['sha256'] for p in files]
assert all(sha(source/p)==h for p,h in inputs.items() if p!=changed) and sha(source/changed)==reader_successor['current_sha256']
result={'schema':'cfg2.host-audit.001','state':'passed','acceptance':False,'host':host,'api_and_ui_cases':1417,'ids':ids,
        'full_cohort':full_pin,'reader_manifest_sha256':f['reader_manifest_sha256'],'reader_count':len(inputs),
        'reader_successor':reader_successor,
        'native_programs':sorted(groups),'new_native_groups':5,'compiled_inputs':738,'compiled_manifest':pin(build/'source-manifest.json'),
        'native_receipt':pin(build/'receipt.json'),'native_xml':pin(build/'native.xml'),'products':f['products'],'application':c['application'],
        'settings_selection_cpp':cpp_pin,'settings_wand_cpp':legacy_pin,'settings_selection_contexts':8,'legacy_wand_contexts':8,
        'sdk':{'receipt':pin(sdk/'receipt.json'),'retirement':pin(sdk/'cache-retirement.json'),'checks_per_file':2348,'ui_files':files,
               'input_reuse':'Original SDK commands/pids and input hashes preserved; exact same immutable UI bytes join final files. No rebuild or fabricated historical command identity.'},
        'rendering':'Two existing hidden-OpenGL checks actually executed; Linux softwareGL; no OS-input/GPU-performance/accessibility certification',
        'limits':'Scoped consumer proof for two existing settings; no full capability-family/hosted-CI/macOS/release acceptance'}
(base/('audit-'+host+'001.json')).write_text(json.dumps(result,indent=2)+'\n')
print(host,'audit passed:738compiled,1417exactcases,8native,8newUIcontexts,8legacyWandcontexts,2SDKfilesx2348checks')
