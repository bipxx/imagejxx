from pathlib import Path
import hashlib,json,os,subprocess,sys,time
windows=os.name=='nt';host='windows' if windows else 'linux'
workspace=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
source=workspace if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
cache=workspace/'.cache/native-verification/windows' if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/cache-native001')
prefix=workspace/'.tmp/p13g-verification/windows/sdk-installed' if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/p13g-resumed-sdk-installed')
base=source/'.tmp/manual-workflow-verification/cfg2';out=base/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
cmake=Path('C:/Program Files/Microsoft Visual Studio/2022/Community/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe') if windows else Path('/usr/bin/cmake')
example=source/'examples/cpp/settings_selection.cpp';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt={'state':'running','acceptance':False,'scope':'Installed public SDK reads actual CPP/Python UI preferences bytes','example_sha256':sha(example),'runs':[],'preferences':[]}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def run(name,args):
    row={'name':name,'argv':list(map(str,args)),'state':'running','started':time.time()};receipt['runs'].append(row);save()
    try:
        with (out/(name+'.log')).open('xb') as log:
            child=subprocess.Popen(row['argv'],cwd=source,stdout=log,stderr=subprocess.STDOUT);row['pid']=child.pid;save();code=child.wait()
        row.update(exit_code=code,reaped=True)
        if code:raise RuntimeError(name+' failed')
        row['state']='passed'
    except BaseException as e:row.update(state='failed',error=str(e));raise
    finally:row['ended']=time.time();save()
save()
try:
    run('install-sdk',[cmake,'--install',cache,'--config','Release','--prefix',prefix,'--component','development'])
    consumer=out/'consumer-cache'
    run('configure',[cmake,'-S',source/'examples/cpp','-B',consumer,'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_PREFIX_PATH='+str(prefix),'-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF','-DBUILD_TESTING=OFF'])
    run('build',[cmake,'--build',consumer,'--config','Release','--parallel','2','--target','imagejxx_settings_selection_example'])
    app=consumer/('Release/imagejxx_settings_selection_example.exe' if windows else 'imagejxx_settings_selection_example')
    receipt['consumer']={'path':str(app),'sha256':sha(app)}
    for index,path in enumerate(sys.argv[2:]):
        path=Path(path).resolve(strict=True);before=sha(path)
        receipt['preferences'].append({'path':str(path),'bytes':path.stat().st_size,'sha256':before});save()
        run('read-'+str(index),[app,path]);assert sha(path)==before
    assert len(receipt['preferences'])==2 and sha(example)==receipt['example_sha256']
    core=prefix/('lib/imagejxx_core.lib' if windows else 'lib/libimagejxx_core.a')
    receipt['core']={'path':str(core),'sha256':sha(core)};receipt['state']='passed'
except BaseException as e:receipt.update(state='failed',error=str(e));raise
finally:save()
