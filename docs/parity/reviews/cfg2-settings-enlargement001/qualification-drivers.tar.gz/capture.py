from pathlib import Path
import hashlib,importlib.util,json,os,sys,time
windows=os.name=='nt';host='windows' if windows else 'linux'
workspace=Path('C:/Users/HEQ/Projects/imagejxx') if windows else Path('/mnt/c/Users/HEQ/Projects/imagejxx')
source=workspace if windows else Path('/home/heq/.cache/imagejxx-build/p08m-001-2aqxi4ay/source001')
out=source/'.tmp/manual-workflow-verification/cfg2'/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
app=workspace/('.tmp/p13g-verification/'+host+'/app-installed/bin/imagejxx'+('.exe' if windows else ''))
spec=importlib.util.spec_from_file_location('cfg2_ci',source/'scripts/ci_observations.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
cases=json.loads(sys.argv[2]) if len(sys.argv)>2 else list(module.SETTINGS_SELECTION_CASES)
receipt={'state':'running','acceptance':False,'cases':cases,'started':time.time(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'ci_producer_sha256':hashlib.sha256((source/'scripts/ci_observations.py').read_bytes()).hexdigest()}
def save():(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save()
try:
    environment=module.capture(out/'cpp',app,source,os.environ.copy(),selected_cases=[['settings-selection',case] for case in cases],case_timeout=60)
    receipt['environment']=environment;(out/'reader-environment.json').write_text(json.dumps(environment,indent=2)+'\n');receipt['state']='observed'
except BaseException as e:receipt.update(state='failed',error=str(e));raise
finally:receipt['ended']=time.time();save()
