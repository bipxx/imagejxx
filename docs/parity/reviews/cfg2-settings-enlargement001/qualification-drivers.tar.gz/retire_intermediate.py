from pathlib import Path, PurePosixPath
import hashlib,json,tarfile,xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[3];out=Path(__file__).resolve().parent
old=root/'.tmp/p13h-verification'
final=json.loads((root/'docs/parity/reviews/p13h-path-authoring001/receipt.json').read_bytes())
protected={Path(r['archive']['path']).name for r in final['retained_archives']}
selected=set(json.loads((root/'docs/parity/reviews/p13h-path-authoring001/selected-python-ids.json').read_bytes())['selected'])
rows=[]
for name,run in [('windows-ui-reader009-scratch-retention.json','windows/ui-reader009'),('linux-ui-reader001-scratch-native-retention.json','linux/ui-reader001')]:
    metadata=old/name;r=json.loads(metadata.read_bytes());archive=old/r['archive']
    assert archive.name not in protected and archive.resolve().parent==old.resolve() and not archive.is_symlink()
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==r['sha256']
    xml=old/run/'pytest.xml';tests=ET.parse(xml).findall('.//testcase')
    ids={c.get('classname').replace('.','/')+'.py::'+c.get('name') for c in tests}
    assert ids and ids<=selected and all(c.find(k) is None for c in tests for k in ('failure','error','skipped'))
    kept=[];destination=out/'intermediate-diagnostics'/archive.name.removesuffix('.tar.gz');destination.mkdir(parents=True,exist_ok=False)
    with tarfile.open(archive) as bundle:
        expected={m['path']:m for m in r['members']};assert set(bundle.getnames())==set(expected)
        for member in bundle.getmembers():
            path=PurePosixPath(member.name);assert not path.is_absolute() and '..' not in path.parts
            e=expected[member.name]
            if e.get('kind')=='symlink':
                assert member.issym() and member.linkname==e['target'];continue
            assert member.isfile() and member.size==e['bytes']
            stream=bundle.extractfile(member);h=hashlib.sha256();count=0
            while part:=stream.read(1024*1024):h.update(part);count+=len(part)
            assert count==e['bytes'] and h.hexdigest()==e['sha256']
            if member.size<=1024*1024:
                p=destination/member.name;p.parent.mkdir(parents=True,exist_ok=True)
                p.write_bytes(bundle.extractfile(member).read());assert hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
                kept.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':e['sha256']})
    for p in (old/run).iterdir():
        if p.is_file() and not p.is_symlink() and p.stat().st_size<=1024*1024:
            saved=destination/('run-'+p.name);saved.write_bytes(p.read_bytes())
            kept.append({'path':str(saved.relative_to(root)),'bytes':saved.stat().st_size,'sha256':hashlib.sha256(saved.read_bytes()).hexdigest()})
    rows.append({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':r['sha256'],'members_verified':len(r['members']),
                 'original_retention':str(metadata),'matched_final_ids':sorted(ids),'preserved':kept,'availability':'retiring'})
record={'schema':'cfg2.superseded-intermediate-retirement.001','acceptance':False,'reason':'Bounded retention of superseded passing component captures; final P13h cohort retains the named checks; historical bytes are not relabelled',
        'final_p13h_receipt_sha256':hashlib.sha256((root/'docs/parity/reviews/p13h-path-authoring001/receipt.json').read_bytes()).hexdigest(),
        'protected_final_archives':sorted(protected),'rows':rows}
p=out/'intermediate-retirement.json';p.write_text(json.dumps(record,indent=2)+'\n')
for row in rows:
    target=Path(row['archive']);assert target.resolve().parent==old.resolve() and target.name not in protected and not target.is_symlink()
    target.unlink();row['availability']='retired-unavailable'
record['removed_bytes']=sum(r['bytes'] for r in rows);p.write_text(json.dumps(record,indent=2)+'\n')
assert all((old/name).is_file() for name in protected)
print('Retired',record['removed_bytes'],'verified intermediate archive bytes;13final archives and small result/session files preserved')
